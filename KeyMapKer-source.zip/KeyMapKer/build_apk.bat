@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found. Open this project in Android Studio or install Gradle 8.9.
  exit /b 1
)
gradle --no-daemon :app:assembleDebug
if errorlevel 1 exit /b 1
if not exist dist mkdir dist
copy /Y app\build\outputs\apk\debug\app-debug.apk dist\KeyMapKer-debug.apk >nul
echo APK created: dist\KeyMapKer-debug.apk

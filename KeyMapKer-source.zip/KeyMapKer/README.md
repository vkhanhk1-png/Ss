# Key MapKer — Android source

A native Android MVP for creating and saving keyboard/mouse layout profiles. The interface is original and uses the product name **Key MapKer**.

## Features in this source

- Dashboard with profile counts and recent profiles.
- Multiple per-game layout profiles.
- Layout editor with movable control points on a preview canvas.
- Assign a key from a list or capture an external keyboard key while the app is open.
- Per-profile mouse sensitivity value.
- Local persistence using Android SharedPreferences.
- Export/import profiles as JSON using the clipboard and a paste dialog.
- Dark UI and custom vector launcher icon.
- GitHub Actions workflow to build and upload a debug APK artifact.

## Important capability note

This MVP edits and stores layouts inside the app. **It does not currently inject touch events into another game or display a working in-game overlay.** A production GG Mouse-style mapper needs an additional Android input/privileged execution layer and a permission/activation flow (for example, carefully designed Shizuku integration), as well as device testing. The current editor is not a drop-in replacement for GG Mouse.

## Build with Android Studio

Requirements:

- Android Studio with Android SDK Platform 35 and Build Tools 35.0.0
- JDK 17
- Gradle 8.9 (Android Studio can usually manage its own Gradle installation)

1. Open the `KeyMapKer` folder in Android Studio.
2. Allow Gradle sync to complete.
3. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The debug APK should be created at `app/build/outputs/apk/debug/app-debug.apk`.

Or with Gradle installed, run:

```bash
./build_apk.sh
```

On Windows, run `build_apk.bat`. These scripts copy the output to `dist/KeyMapKer-debug.apk`.

## Build with GitHub Actions

Push this folder to a GitHub repository. Open the **Actions** tab and run **Build Key MapKer APK** (or push to `main`/`master`). Download the `KeyMapKer-debug-apk` artifact from that workflow run. The artifact is a debug-signed APK for testing, not a Play Store release.

## App identifiers

- Display name: `Key MapKer`
- Package: `com.vkhanh.keymapker`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- Version: 1.0.0

#!/usr/bin/env bash
set -euo pipefail

if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Open this project with Android Studio or install Gradle 8.9 first." >&2
  exit 1
fi

gradle --no-daemon :app:assembleDebug
mkdir -p dist
cp app/build/outputs/apk/debug/app-debug.apk dist/KeyMapKer-debug.apk
echo "APK created: dist/KeyMapKer-debug.apk"

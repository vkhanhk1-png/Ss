package com.vkhanh.keymapker

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.min

private object Palette {
    const val BG = 0xFF0B0B12.toInt()
    const val PANEL = 0xFF151521.toInt()
    const val PANEL_ALT = 0xFF1C1C2B.toInt()
    const val PURPLE = 0xFF8B5CF6.toInt()
    const val CYAN = 0xFF22D3EE.toInt()
    const val TEXT = 0xFFF4F4FB.toInt()
    const val MUTED = 0xFFA1A1B5.toInt()
    const val LINE = 0xFF2D2D40.toInt()
    const val GREEN = 0xFF34D399.toInt()
    const val RED = 0xFFFB7185.toInt()
}

private data class KeyBinding(
    var name: String,
    var key: String,
    var x: Float,
    var y: Float
)

private data class GameProfile(
    var name: String,
    var bindings: MutableList<KeyBinding>,
    var sensitivity: Int = 50
)

class MainActivity : Activity() {
    private lateinit var contentFrame: FrameLayout
    private lateinit var navHome: TextView
    private lateinit var navMaps: TextView
    private lateinit var navSettings: TextView
    private val prefs by lazy { getSharedPreferences("keymapker_store", Context.MODE_PRIVATE) }
    private val profiles = mutableListOf<GameProfile>()
    private var activeProfileIndex = 0
    private var currentTab = "home"
    private var selectedBindingIndex = 0
    private var assigningKey = false
    private var lastInputText = "Chưa phát hiện thiết bị nhập"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Palette.BG
        window.navigationBarColor = Palette.BG
        loadProfiles()
        setContentView(buildShell())
        showScreen("home")
    }

    private fun buildShell(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.BG)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(14))
            setBackgroundColor(Palette.BG)
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("KEY MAPKER", 18f, Palette.TEXT, true))
        brand.addView(label("KEYBOARD  ·  MOUSE  ·  CONTROL", 9f, Palette.MUTED, true).also {
            it.letterSpacing = 0.08f
            it.setPadding(0, dp(3), 0, 0)
        })
        header.addView(brand, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val version = label("V1.0", 10f, Palette.CYAN, true).apply {
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setBackground(roundDrawable(Palette.PANEL_ALT, 12))
        }
        header.addView(version)
        root.addView(header)

        contentFrame = FrameLayout(this).apply { setBackgroundColor(Palette.BG) }
        root.addView(contentFrame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(9), dp(10), dp(10))
            setBackgroundColor(Palette.PANEL)
        }
        navHome = navItem("⌂\nTRANG CHỦ", "home")
        navMaps = navItem("⌘\nKEY MAP", "maps")
        navSettings = navItem("⚙\nCÀI ĐẶT", "settings")
        nav.addView(navHome, LinearLayout.LayoutParams(0, dp(52), 1f))
        nav.addView(navMaps, LinearLayout.LayoutParams(0, dp(52), 1f))
        nav.addView(navSettings, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(nav)
        return root
    }

    private fun navItem(text: String, tab: String): TextView = label(text, 10f, Palette.MUTED, true).apply {
        gravity = Gravity.CENTER
        setOnClickListener { showScreen(tab) }
    }

    private fun showScreen(tab: String) {
        currentTab = tab
        navHome.setTextColor(if (tab == "home") Palette.CYAN else Palette.MUTED)
        navMaps.setTextColor(if (tab == "maps" || tab == "editor") Palette.CYAN else Palette.MUTED)
        navSettings.setTextColor(if (tab == "settings") Palette.CYAN else Palette.MUTED)
        contentFrame.removeAllViews()
        val view = when (tab) {
            "maps" -> mapsScreen()
            "settings" -> settingsScreen()
            "editor" -> editorScreen()
            else -> homeScreen()
        }
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(dp(18), dp(1), dp(18), dp(10))
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            addView(view, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        contentFrame.addView(scroll, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
    }

    private fun homeScreen(): View {
        val body = verticalScroll()
        body.addView(sectionTitle("Xin chào, game thủ", "Thiết lập góc điều khiển theo cách của bạn."))

        val status = card()
        val statusRow = horizontal()
        val statusIcon = label("●", 16f, Palette.GREEN, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(13), dp(8), dp(13), dp(8))
            setBackground(roundDrawable(0x2222D399, 14))
        }
        statusRow.addView(statusIcon)
        val statusText = vertical()
        statusText.addView(label("KEYMAP WORKSPACE", 10f, Palette.CYAN, true))
        statusText.addView(label("Bộ chỉnh sửa cấu hình đang sẵn sàng", 13f, Palette.TEXT, true).apply {
            setPadding(0, dp(4), 0, 0)
        })
        statusRow.addView(statusText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        status.addView(statusRow)
        status.addView(label("Bản hiện tại lưu cấu hình cục bộ; chưa tự chèn thao tác chạm vào game bên ngoài.", 11f, Palette.MUTED, false).apply {
            setPadding(0, dp(12), 0, 0)
        })
        body.addView(status)

        val stats = horizontal().apply { setPadding(0, dp(12), 0, dp(3)) }
        stats.addView(statCard("${profiles.size}", "HỒ SƠ GAME"), LinearLayout.LayoutParams(0, dp(84), 1f).also { it.setMargins(0, 0, dp(7), 0) })
        val totalBindings = profiles.sumOf { it.bindings.size }
        stats.addView(statCard("$totalBindings", "PHÍM ĐÃ GÁN"), LinearLayout.LayoutParams(0, dp(84), 1f).also { it.setMargins(dp(7), 0, 0, 0) })
        body.addView(stats)

        body.addView(sectionTitle("Hồ sơ gần đây", "Chọn một hồ sơ để tiếp tục."))
        profiles.take(3).forEachIndexed { index, profile ->
            body.addView(profileRow(profile, index, true))
        }
        val actions = horizontal().apply { setPadding(0, dp(15), 0, dp(12)) }
        actions.addView(actionButton("＋  TẠO HỒ SƠ", true) { promptNewProfile() }, LinearLayout.LayoutParams(0, dp(48), 1f).also { it.setMargins(0, 0, dp(6), 0) })
        actions.addView(actionButton("MỞ KEY MAP  →", false) { showScreen("editor") }, LinearLayout.LayoutParams(0, dp(48), 1f).also { it.setMargins(dp(6), 0, 0, 0) })
        body.addView(actions)
        return body
    }

    private fun mapsScreen(): View {
        val body = verticalScroll()
        body.addView(sectionTitle("Hồ sơ Key Map", "Mỗi game có thể dùng một bố cục riêng."))
        profiles.forEachIndexed { index, profile -> body.addView(profileRow(profile, index, false)) }
        body.addView(actionButton("＋  TẠO HỒ SƠ MỚI", true) { promptNewProfile() }.apply {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
            lp.setMargins(0, dp(12), 0, dp(18))
            layoutParams = lp
        })
        return body
    }

    private fun settingsScreen(): View {
        val body = verticalScroll()
        body.addView(sectionTitle("Cài đặt", "Tuỳ chỉnh ứng dụng Key MapKer."))
        body.addView(settingCard("Thiết bị đầu vào", lastInputText, "Nhấn một phím vật lý khi màn hình ứng dụng đang mở để kiểm tra nhận phím."))
        body.addView(settingCard("Lưu dữ liệu", "Lưu trên thiết bị", "Hồ sơ và tọa độ được lưu trong bộ nhớ riêng của ứng dụng."))
        body.addView(settingCard("Trạng thái tính năng", "Key map editor · Bản MVP", "Bản này chỉnh sửa và lưu bố cục. Gửi sự kiện chạm sang game khác cần lớp quyền hệ thống riêng, chưa được bật trong bản này."))
        body.addView(actionButton("XUẤT CẤU HÌNH JSON", false) { exportProfiles() }.apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).also { it.setMargins(0, dp(12), 0, dp(8)) }
        })
        body.addView(actionButton("NHẬP CẤU HÌNH JSON", false) { importProfilesPrompt() }.apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).also { it.setMargins(0, 0, 0, dp(8)) }
        })
        body.addView(actionButton("ĐẶT LẠI DỮ LIỆU MẪU", false) {
            AlertDialog.Builder(this).setTitle("Đặt lại dữ liệu?")
                .setMessage("Các hồ sơ hiện tại sẽ được thay bằng dữ liệu mẫu.")
                .setNegativeButton("Huỷ", null)
                .setPositiveButton("Đặt lại") { _, _ ->
                    prefs.edit().remove("profiles_json").apply()
                    loadProfiles()
                    showScreen("settings")
                }.show()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).also { it.setMargins(0, 0, 0, dp(18)) }
        })
        return body
    }

    private fun editorScreen(): View {
        val profile = activeProfile()
        selectedBindingIndex = selectedBindingIndex.coerceIn(0, (profile.bindings.size - 1).coerceAtLeast(0))
        val body = verticalScroll()
        val heading = horizontal().apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(12))
        }
        heading.addView(actionButton("←", false, compact = true) { showScreen("maps") }, LinearLayout.LayoutParams(dp(45), dp(42)))
        val headText = vertical().apply { setPadding(dp(10), 0, 0, 0) }
        headText.addView(label("CHỈNH SỬA KEY MAP", 11f, Palette.CYAN, true))
        headText.addView(label(profile.name, 18f, Palette.TEXT, true).apply { setPadding(0, dp(3), 0, 0) })
        heading.addView(headText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        body.addView(heading)

        body.addView(label("Kéo điểm để đặt vị trí; dùng các thẻ bên dưới để chọn điểm cần sửa tên hoặc gán phím.", 11f, Palette.MUTED, false).apply {
            setPadding(dp(2), 0, dp(2), dp(10))
        })
        val mapCanvas = KeymapCanvas(this, profile.bindings, selectedBindingIndex,
            onSelected = { _ ->
                // The canvas highlights a tapped point. Use the binding chips below
                // to switch the editable property panel without interrupting a drag.
                assigningKey = false
            },
            onMoved = { index, x, y ->
                if (index in profile.bindings.indices) {
                    profile.bindings[index].x = x
                    profile.bindings[index].y = y
                    saveProfiles()
                }
            }
        )
        body.addView(mapCanvas, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(270)))
        val pickerScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(5), 0, dp(2))
        }
        val pickerRow = horizontal()
        profile.bindings.forEachIndexed { index, binding ->
            val chip = actionButton("${binding.key.take(5)} · ${binding.name}", index == selectedBindingIndex, compact = true) {
                selectedBindingIndex = index
                showScreen("editor")
            }
            pickerRow.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)).also {
                it.setMargins(0, 0, dp(7), 0)
            })
        }
        pickerScroll.addView(pickerRow)
        body.addView(pickerScroll)

        val selected = profile.bindings.getOrNull(selectedBindingIndex)
        body.addView(sectionTitle("Phím điều khiển", "${profile.bindings.size} điểm trong bố cục"))
        if (selected == null) {
            body.addView(label("Chưa có điểm điều khiển. Hãy thêm điểm mới.", 12f, Palette.MUTED, false))
        } else {
            val editCard = card()
            editCard.addView(label("ĐIỂM ĐANG CHỌN", 9f, Palette.CYAN, true))
            val nameInput = EditText(this).apply {
                setText(selected.name)
                setTextColor(Palette.TEXT)
                textSize = 14f
                setSingleLine(true)
                hint = "Tên hành động"
                setHintTextColor(Palette.MUTED)
                background = roundDrawable(Palette.PANEL_ALT, 10)
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            editCard.addView(nameInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).also { it.setMargins(0, dp(8), 0, dp(9)) })
            val keyRow = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
            val keyInfo = vertical()
            keyInfo.addView(label("PHÍM GÁN", 9f, Palette.MUTED, true))
            keyInfo.addView(label(selected.key, 16f, Palette.TEXT, true).apply { setPadding(0, dp(3), 0, 0) })
            keyRow.addView(keyInfo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            keyRow.addView(actionButton("CHỌN DANH SÁCH", true, compact = true) { promptKeyChoice() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)))
            editCard.addView(keyRow)
            editCard.addView(actionButton("GÁN TỪ BÀN PHÍM VẬT LÝ", false, compact = true) {
                assigningKey = true
                toast("Nhấn một phím trên bàn phím đang kết nối…")
            }.apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)).also { it.setMargins(0, dp(9), 0, 0) }
            })
            editCard.addView(label("TỌA ĐỘ: ${(selected.x * 100).toInt()}% ngang · ${(selected.y * 100).toInt()}% dọc", 10f, Palette.MUTED, false).apply {
                setPadding(0, dp(10), 0, 0)
            })
            editCard.addView(label("ĐỘ NHẠY CHUỘT · ${profile.sensitivity}%", 10f, Palette.MUTED, true).apply {
                setPadding(0, dp(12), 0, dp(1))
            })
            val sensitivity = SeekBar(this).apply {
                max = 100
                progress = profile.sensitivity
                progressTintList = android.content.res.ColorStateList.valueOf(Palette.CYAN)
                thumbTintList = android.content.res.ColorStateList.valueOf(Palette.CYAN)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        profile.sensitivity = progress
                        saveProfiles()
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) { showScreen("editor") }
                })
            }
            editCard.addView(sensitivity)
            body.addView(editCard)
            nameInput.setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus && selected.name != nameInput.text.toString().trim() && nameInput.text.toString().trim().isNotEmpty()) {
                    selected.name = nameInput.text.toString().trim()
                    saveProfiles()
                }
            }
        }

        val buttons = horizontal().apply { setPadding(0, dp(10), 0, dp(18)) }
        buttons.addView(actionButton("＋ THÊM ĐIỂM", true) {
            profile.bindings.add(KeyBinding("Nút mới", "Chưa gán", 0.5f, 0.5f))
            selectedBindingIndex = profile.bindings.lastIndex
            saveProfiles()
            showScreen("editor")
        }, LinearLayout.LayoutParams(0, dp(46), 1f).also { it.setMargins(0, 0, dp(5), 0) })
        buttons.addView(actionButton("XÓA ĐIỂM", false) {
            if (profile.bindings.isNotEmpty() && selectedBindingIndex in profile.bindings.indices) {
                profile.bindings.removeAt(selectedBindingIndex)
                selectedBindingIndex = (selectedBindingIndex - 1).coerceAtLeast(0)
                saveProfiles()
                showScreen("editor")
            }
        }, LinearLayout.LayoutParams(0, dp(46), 1f).also { it.setMargins(dp(5), 0, 0, 0) })
        body.addView(buttons)
        body.addView(label("Lưu ý: đây là trình thiết kế bố cục trong ứng dụng, chưa chuyển phím thành chạm trong game.", 10f, Palette.MUTED, false).apply {
            setPadding(dp(2), 0, dp(2), dp(20))
        })
        return body
    }

    private fun profileRow(profile: GameProfile, index: Int, compact: Boolean): View {
        val wrapper = card().apply { isClickable = true; isFocusable = true }
        val row = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
        val glyph = label(gameGlyph(profile.name), 18f, Palette.CYAN, true).apply {
            gravity = Gravity.CENTER
            setBackground(roundDrawable(Palette.PANEL_ALT, 13))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        row.addView(glyph)
        val info = vertical().apply { setPadding(dp(12), 0, 0, 0) }
        info.addView(label(profile.name, 14f, Palette.TEXT, true))
        info.addView(label("${profile.bindings.size} điểm · Độ nhạy ${profile.sensitivity}%", 10f, Palette.MUTED, false).apply {
            setPadding(0, dp(5), 0, 0)
        })
        row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(label("✎", 19f, Palette.PURPLE, true).apply { setPadding(dp(10), dp(8), dp(2), dp(8)) })
        wrapper.addView(row)
        wrapper.setOnClickListener {
            activeProfileIndex = index
            selectedBindingIndex = 0
            showScreen("editor")
        }
        return wrapper
    }

    private fun statCard(value: String, caption: String): View {
        val box = card().apply { setPadding(dp(14), dp(11), dp(14), dp(11)) }
        box.addView(label(value, 23f, Palette.TEXT, true))
        box.addView(label(caption, 9f, Palette.MUTED, true).apply { setPadding(0, dp(4), 0, 0) })
        return box
    }

    private fun settingCard(title: String, value: String, detail: String): View {
        val box = card()
        box.addView(label(title, 12f, Palette.MUTED, true))
        box.addView(label(value, 15f, Palette.TEXT, true).apply { setPadding(0, dp(5), 0, 0) })
        box.addView(label(detail, 11f, Palette.MUTED, false).apply { setPadding(0, dp(7), 0, 0) })
        return box
    }

    private fun sectionTitle(title: String, subtitle: String): View {
        val v = vertical().apply { setPadding(0, dp(19), 0, dp(10)) }
        v.addView(label(title, 19f, Palette.TEXT, true))
        v.addView(label(subtitle, 11f, Palette.MUTED, false).apply { setPadding(0, dp(5), 0, 0) })
        return v
    }

    private fun card(): LinearLayout = vertical().apply {
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = roundDrawable(Palette.PANEL, 17)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(5), 0, dp(5))
        layoutParams = lp
    }

    private fun vertical(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun horizontal(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

    private fun verticalScroll(): LinearLayout = vertical().apply {
        setPadding(0, 0, 0, dp(10))
    }

    private fun actionButton(text: String, primary: Boolean, compact: Boolean = false, onClick: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = if (compact) 10f else 11f
            setTextColor(if (primary) Palette.BG else Palette.TEXT)
            background = roundDrawable(if (primary) Palette.CYAN else Palette.PANEL_ALT, 12)
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(if (compact) 12 else 10), dp(7), dp(if (compact) 12 else 10), dp(7))
            stateListAnimator = null
            setOnClickListener { onClick() }
        }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        includeFontPadding = true
    }

    private fun roundDrawable(color: Int, radiusDp: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun gameGlyph(name: String): String = when {
        name.contains("free", true) -> "F"
        name.contains("fps", true) -> "◎"
        else -> "⌘"
    }

    private fun promptNewProfile() {
        val input = EditText(this).apply {
            hint = "Tên hồ sơ, ví dụ: My Game"
            setTextColor(Palette.TEXT)
            setHintTextColor(Palette.MUTED)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = roundDrawable(Palette.PANEL_ALT, 10)
        }
        val container = vertical().apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        }
        AlertDialog.Builder(this).setTitle("Tạo hồ sơ game")
            .setView(container)
            .setNegativeButton("Huỷ", null)
            .setPositiveButton("Tạo") { _, _ ->
                val name = input.text.toString().trim().ifBlank { "Hồ sơ ${profiles.size + 1}" }
                profiles.add(GameProfile(name, mutableListOf(
                    KeyBinding("Di chuyển", "W", 0.20f, 0.70f),
                    KeyBinding("Nhảy", "SPACE", 0.82f, 0.73f),
                    KeyBinding("Tương tác", "F", 0.72f, 0.54f)
                )))
                activeProfileIndex = profiles.lastIndex
                selectedBindingIndex = 0
                saveProfiles()
                showScreen("editor")
            }.show()
    }

    private fun promptKeyChoice() {
        val keys = arrayOf("W", "A", "S", "D", "SPACE", "SHIFT", "CTRL", "ALT", "E", "F", "R", "Q", "1", "2", "3", "4", "Mouse Left", "Mouse Right", "Mouse Middle")
        AlertDialog.Builder(this)
            .setTitle("Chọn phím cho điểm điều khiển")
            .setItems(keys) { _, which ->
                activeProfile().bindings.getOrNull(selectedBindingIndex)?.key = keys[which]
                saveProfiles()
                showScreen("editor")
            }.setNegativeButton("Huỷ", null).show()
    }

    private fun exportProfiles() {
        val json = serializeProfiles().toString(2)
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Key MapKer profiles", json))
        AlertDialog.Builder(this).setTitle("Đã sao chép JSON")
            .setMessage("Cấu hình đã được sao chép vào clipboard. Hãy dán vào nơi lưu trữ của bạn để tạo bản sao lưu.\n\n${json.take(450)}${if (json.length > 450) "…" else ""}")
            .setPositiveButton("Đóng", null).show()
    }

    private fun importProfilesPrompt() {
        val input = EditText(this).apply {
            hint = "Dán nội dung JSON đã xuất"
            setTextColor(Palette.TEXT)
            setHintTextColor(Palette.MUTED)
            gravity = Gravity.TOP
            minLines = 5
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = roundDrawable(Palette.PANEL_ALT, 10)
        }
        val container = vertical().apply {
            setPadding(dp(18), dp(8), dp(18), 0)
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(160)))
        }
        AlertDialog.Builder(this).setTitle("Nhập cấu hình JSON")
            .setView(container)
            .setNegativeButton("Huỷ", null)
            .setPositiveButton("Nhập") { _, _ ->
                try {
                    val arr = JSONArray(input.text.toString())
                    val parsed = mutableListOf<GameProfile>()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val bindingsJson = item.optJSONArray("bindings") ?: JSONArray()
                        val bindings = mutableListOf<KeyBinding>()
                        for (j in 0 until bindingsJson.length()) {
                            val b = bindingsJson.getJSONObject(j)
                            bindings.add(KeyBinding(b.optString("name", "Nút"), b.optString("key", "Chưa gán"), b.optDouble("x", 0.5).toFloat().coerceIn(0f, 1f), b.optDouble("y", 0.5).toFloat().coerceIn(0f, 1f)))
                        }
                        parsed.add(GameProfile(item.optString("name", "Hồ sơ"), bindings, item.optInt("sensitivity", 50).coerceIn(0, 100)))
                    }
                    if (parsed.isEmpty()) throw IllegalArgumentException("empty profile list")
                    profiles.clear(); profiles.addAll(parsed)
                    activeProfileIndex = 0; selectedBindingIndex = 0
                    saveProfiles()
                    showScreen("settings")
                    toast("Đã nhập ${profiles.size} hồ sơ")
                } catch (_: Exception) {
                    toast("JSON không hợp lệ hoặc không đúng định dạng Key MapKer")
                }
            }.show()
    }

    private fun loadProfiles() {
        profiles.clear()
        val raw = prefs.getString("profiles_json", null)
        if (!raw.isNullOrBlank()) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val bArr = obj.optJSONArray("bindings") ?: JSONArray()
                    val bindings = mutableListOf<KeyBinding>()
                    for (j in 0 until bArr.length()) {
                        val b = bArr.getJSONObject(j)
                        bindings.add(KeyBinding(
                            b.optString("name", "Nút"), b.optString("key", "Chưa gán"),
                            b.optDouble("x", 0.5).toFloat().coerceIn(0f, 1f),
                            b.optDouble("y", 0.5).toFloat().coerceIn(0f, 1f)
                        ))
                    }
                    profiles.add(GameProfile(obj.optString("name", "Hồ sơ"), bindings, obj.optInt("sensitivity", 50).coerceIn(0, 100)))
                }
            } catch (_: Exception) { profiles.clear() }
        }
        if (profiles.isEmpty()) {
            profiles.add(GameProfile("Free Fire · Layout", mutableListOf(
                KeyBinding("Di chuyển", "W A S D", 0.20f, 0.68f),
                KeyBinding("Nhảy", "SPACE", 0.85f, 0.74f),
                KeyBinding("Ngồi", "C", 0.73f, 0.82f),
                KeyBinding("Tương tác", "F", 0.76f, 0.55f),
                KeyBinding("Nạp đạn", "R", 0.89f, 0.37f)
            ), 50))
            profiles.add(GameProfile("FPS Training", mutableListOf(
                KeyBinding("Di chuyển", "W A S D", 0.20f, 0.68f),
                KeyBinding("Nhảy", "SPACE", 0.84f, 0.76f),
                KeyBinding("Nạp đạn", "R", 0.80f, 0.40f)
            ), 55))
            profiles.add(GameProfile("Hồ sơ mới", mutableListOf(
                KeyBinding("Điểm 1", "E", 0.50f, 0.50f)
            ), 50))
            saveProfiles()
        }
        activeProfileIndex = activeProfileIndex.coerceIn(0, profiles.lastIndex.coerceAtLeast(0))
    }

    private fun serializeProfiles(): JSONArray {
        val arr = JSONArray()
        profiles.forEach { profile ->
            val obj = JSONObject()
            obj.put("name", profile.name)
            obj.put("sensitivity", profile.sensitivity)
            val bArr = JSONArray()
            profile.bindings.forEach { binding ->
                val b = JSONObject()
                b.put("name", binding.name); b.put("key", binding.key)
                b.put("x", binding.x.toDouble()); b.put("y", binding.y.toDouble())
                bArr.put(b)
            }
            obj.put("bindings", bArr)
            arr.put(obj)
        }
        return arr
    }

    private fun saveProfiles() { prefs.edit().putString("profiles_json", serializeProfiles().toString()).apply() }
    private fun activeProfile(): GameProfile = profiles[activeProfileIndex.coerceIn(0, profiles.lastIndex.coerceAtLeast(0))]

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode != KeyEvent.KEYCODE_BACK) {
            val device = event.device
            val deviceName = device?.name ?: "Bàn phím"
            lastInputText = "Nhận phím ${KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_")} · $deviceName"
            if (assigningKey) {
                activeProfile().bindings.getOrNull(selectedBindingIndex)?.key = prettyKey(event)
                assigningKey = false
                saveProfiles()
                showScreen("editor")
                toast("Đã gán phím ${prettyKey(event)}")
                return true
            }
            if (currentTab == "settings") showScreen("settings")
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE) {
            lastInputText = if (event.action == MotionEvent.ACTION_HOVER_MOVE) "Đã nhận chuyển động chuột" else "Đã nhận sự kiện chuột"
            if (currentTab == "settings") showScreen("settings")
        }
        return super.onGenericMotionEvent(event)
    }

    private fun prettyKey(event: KeyEvent): String = when (event.keyCode) {
        KeyEvent.KEYCODE_SPACE -> "SPACE"
        KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> "SHIFT"
        KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> "CTRL"
        KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT -> "ALT"
        else -> KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_").replace("NUMPAD_", "NUM ")
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private inner class KeymapCanvas(
        context: Context,
        private val bindings: MutableList<KeyBinding>,
        private var selected: Int,
        private val onSelected: (Int) -> Unit,
        private val onMoved: (Int, Float, Float) -> Unit
    ) : View(context) {
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Palette.LINE; strokeWidth = dp(1).toFloat() }
        private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = dp(10).toFloat(); typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
        private var draggingIndex = -1
        private val area = RectF()

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Palette.BG)
            val left = dp(3).toFloat()
            val top = dp(3).toFloat()
            val right = width - dp(3).toFloat()
            val bottom = height - dp(3).toFloat()
            area.set(left, top, right, bottom)
            bgPaint.color = 0xFF11111B.toInt()
            canvas.drawRoundRect(area, dp(16).toFloat(), dp(16).toFloat(), bgPaint)
            canvas.save()
            canvas.clipRect(area)
            val stepX = area.width() / 8f
            val stepY = area.height() / 6f
            var x = area.left
            while (x <= area.right) { canvas.drawLine(x, area.top, x, area.bottom, gridPaint); x += stepX }
            var y = area.top
            while (y <= area.bottom) { canvas.drawLine(area.left, y, area.right, y, gridPaint); y += stepY }
            // Decorative HUD mockup; this is only a layout canvas, not a game renderer.
            bgPaint.color = 0x3322D3EE
            canvas.drawCircle(area.left + area.width() * 0.20f, area.top + area.height() * 0.70f, dp(35).toFloat(), bgPaint)
            bgPaint.color = 0x228B5CF6
            canvas.drawCircle(area.left + area.width() * 0.82f, area.top + area.height() * 0.70f, dp(29).toFloat(), bgPaint)
            textPaint.color = 0x668B8BA2
            textPaint.textSize = dp(9).toFloat()
            canvas.drawText("LAYOUT PREVIEW", area.left + dp(12), area.top + dp(18), textPaint)
            canvas.drawText("DRAG TO POSITION", area.left + dp(12), area.bottom - dp(11), textPaint)

            bindings.forEachIndexed { index, binding ->
                val cx = area.left + binding.x.coerceIn(0f, 1f) * area.width()
                val cy = area.top + binding.y.coerceIn(0f, 1f) * area.height()
                val isSelected = index == selected
                pointPaint.color = if (isSelected) Palette.CYAN else Palette.PURPLE
                canvas.drawCircle(cx, cy, dp(if (isSelected) 19 else 16).toFloat(), pointPaint)
                pointPaint.color = 0xFF10101A.toInt()
                canvas.drawCircle(cx, cy, dp(14).toFloat(), pointPaint)
                pointPaint.color = if (isSelected) Palette.CYAN else Palette.TEXT
                textPaint.color = if (isSelected) Palette.CYAN else Palette.TEXT
                textPaint.textSize = dp(9).toFloat()
                val key = binding.key.take(7)
                val tw = textPaint.measureText(key)
                canvas.drawText(key, cx - tw / 2f, cy + dp(3).toFloat(), textPaint)
                if (isSelected) {
                    pointPaint.color = Palette.CYAN
                    pointPaint.style = Paint.Style.STROKE
                    pointPaint.strokeWidth = dp(1).toFloat()
                    canvas.drawCircle(cx, cy, dp(23).toFloat(), pointPaint)
                    pointPaint.style = Paint.Style.FILL
                }
            }
            canvas.restore()
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val localX = ((event.x - area.left) / area.width().coerceAtLeast(1f)).coerceIn(0f, 1f)
            val localY = ((event.y - area.top) / area.height().coerceAtLeast(1f)).coerceIn(0f, 1f)
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    var nearest = -1
                    var nearestDistance = Float.MAX_VALUE
                    bindings.forEachIndexed { index, b ->
                        val dx = (b.x - localX) * area.width()
                        val dy = (b.y - localY) * area.height()
                        val distance = dx * dx + dy * dy
                        if (distance < nearestDistance) { nearestDistance = distance; nearest = index }
                    }
                    if (nearest >= 0 && nearestDistance < dp(48).toFloat() * dp(48).toFloat()) {
                        draggingIndex = nearest
                        selected = nearest
                        onSelected(nearest)
                    } else {
                        draggingIndex = selected.takeIf { it in bindings.indices } ?: -1
                        if (draggingIndex >= 0) {
                            bindings[draggingIndex].x = localX
                            bindings[draggingIndex].y = localY
                            onMoved(draggingIndex, localX, localY)
                        }
                    }
                    invalidate(); return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (draggingIndex in bindings.indices) {
                        bindings[draggingIndex].x = localX
                        bindings[draggingIndex].y = localY
                        onMoved(draggingIndex, localX, localY)
                        invalidate()
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    draggingIndex = -1
                    performClick()
                    return true
                }
            }
            return true
        }

        override fun performClick(): Boolean {
            super.performClick()
            return true
        }
    }
}
